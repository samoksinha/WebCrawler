import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginMyBookComponent } from './login-my-book/login-my-book.component';
import { HomeMyBookComponent } from './home-my-book/home-my-book.component';
import { AuthguardService } from './service/auth-guard-service.service';
import { SignupMyBookComponent } from './signup-my-book/signup-my-book.component';
import { FavouriteMyBookComponent } from './favourite-my-book/favourite-my-book.component';
import { ForgotPasswordMyBookComponent } from './forgot-password-my-book/forgot-password-my-book.component';

const myBoookRoutes: Routes = [
  {
    path: 'mybooklogin',
    component: LoginMyBookComponent
  },
  {
    path: 'mybooklogin/mybookforgotpassword',
    component: ForgotPasswordMyBookComponent
  },
  {
    path: 'mybooksignup',
    component: SignupMyBookComponent
  },
  {
    path: 'mybookhome',
    component: HomeMyBookComponent,
    canActivate: [AuthguardService]
  },
  {
    path: 'mybookfavourite',
    component: FavouriteMyBookComponent,
    canActivate: [AuthguardService]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(myBoookRoutes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
