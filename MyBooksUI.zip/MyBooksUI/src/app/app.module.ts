import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTableModule } from '@angular/material/table';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import {MatDialogModule} from '@angular/material/dialog';
import { NgxPaginationModule } from 'ngx-pagination';
import { FlexLayoutModule } from '@angular/flex-layout';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderMyBookComponent } from './header-my-book/header-my-book.component';
import { LoginMyBookComponent } from './login-my-book/login-my-book.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeMyBookComponent } from './home-my-book/home-my-book.component';
import { SignupMyBookComponent } from './signup-my-book/signup-my-book.component';
import { SearchBookHttpErrorInterceptor } from './error-my-book/search-book-error-interceptor';
import { DialougeMyBookComponent } from './dialouge-my-book/dialouge-my-book.component';
import { FavouriteMyBookComponent } from './favourite-my-book/favourite-my-book.component';
import { ForgotPasswordMyBookComponent } from './forgot-password-my-book/forgot-password-my-book.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderMyBookComponent,
    LoginMyBookComponent,
    HomeMyBookComponent,
    SignupMyBookComponent,
    DialougeMyBookComponent,
    FavouriteMyBookComponent,
    ForgotPasswordMyBookComponent
  ],
  entryComponents: [
    DialougeMyBookComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatSidenavModule,
    MatToolbarModule,
    MatCardModule,
    MatExpansionModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatProgressSpinnerModule,
    MatTableModule,
    MatProgressBarModule,
    MatDialogModule,
    NgxPaginationModule,
    FlexLayoutModule,
    AppRoutingModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: SearchBookHttpErrorInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }