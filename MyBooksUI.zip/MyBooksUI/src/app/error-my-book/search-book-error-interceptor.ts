import { HttpInterceptor, HttpEvent, HttpHandler, HttpRequest, HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { retry, catchError } from 'rxjs/operators';
import { SearchBookError } from "../model/search-book.-error.model";
import { SearchBookApiError } from "../model/search-book.-api-error.model.";


export class SearchBookHttpErrorInterceptor implements HttpInterceptor {

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request)
      .pipe(retry(1),
        catchError((error : HttpErrorResponse) => {
          
          let searchBookError : SearchBookError;
          let searchBookApiError : SearchBookApiError;
          if (error.error instanceof ErrorEvent) {
            // client-side error
            searchBookError = new SearchBookError(`${error.status}`, 
              `${error.error.message}`, 
              "CLEINT_HTTP_ERROR", null);
          } else {
            // server-side error
            //alert("Error Intercepter : " +JSON.stringify(error));
            searchBookApiError = JSON.parse(JSON.stringify(error.error));
            searchBookError = new SearchBookError(`${error.status}`, 
              `${error.message}`, 
              "SERVER_HTTP_ERROR", searchBookApiError);
          }

          //alert(searchBookError.getErrorMessage());
          return throwError(searchBookError);
        })
      )
  }

}
