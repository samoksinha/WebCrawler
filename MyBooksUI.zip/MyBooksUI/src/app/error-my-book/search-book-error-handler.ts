import { SearchBookError } from "../model/search-book.-error.model";
import { ErrorHandler } from "@angular/core";


export class SearchBookErrorHandler implements ErrorHandler {

  handleError(error) : void {
    //let searchBookError : SearchBookError = new SearchBookError();
    //throw new Error();
  }
}
