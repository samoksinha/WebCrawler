import { Component, OnInit } from '@angular/core';
import { SearchBookDetails } from '../model/search-book-details.model';
import { DataCommunicationServiceService } from '../service/data-communication-service.service';
import { FetchBookService } from '../service/fetch-book-service.service';
import { AuthenticateService } from '../service/authenticate-service.service';
import { MatDialog } from '@angular/material/dialog';
import { DialougeMyBookComponent } from '../dialouge-my-book/dialouge-my-book.component';
import { SearchBookDialouge } from '../model/search-book-dialouge.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-favourite-my-book',
  templateUrl: './favourite-my-book.component.html',
  styleUrls: ['./favourite-my-book.component.css']
})
export class FavouriteMyBookComponent implements OnInit {

  private _progressLoader : boolean;
  private _errorMessage : string;
  private _errorMessageFlag : boolean;
  private _searchDataFlag : boolean;
  private _itemsPerPage : number;
  private _currentPage : number;
  private _dialouge: MatDialog;

  private _searchBookDetailsList : SearchBookDetails[];
  private _fetchBookService : FetchBookService;
  private _authenticateService : AuthenticateService;
  private _router : Router;

  constructor(fetchBookService : FetchBookService,
              authenticateService : AuthenticateService,
              dialouge: MatDialog,
              router : Router) { 

    this._fetchBookService = fetchBookService;
    this._authenticateService = authenticateService;
    this._router = router;

    this._progressLoader = false;
    this._errorMessage = "";
    this._errorMessageFlag = false;
    this._searchDataFlag = false;
    this._itemsPerPage = 3;
    this._currentPage =1;
    this._dialouge = dialouge;
  }

  ngOnInit() {
    this.getFavouriteBooks();
  }

  get ProgressLoader() : boolean {
    return this._progressLoader;
  }

  get ErrorMessage() {
    return this._errorMessage;
  }

  get ErrorMessageFlag() {
    return this._errorMessageFlag;
  }

  get SearchBookDetailsList() {
    return this._searchBookDetailsList;
  }

  get SearchDataFlag() {
    return this._searchDataFlag;
  }

  get ItemsPerPage() {
    return this._itemsPerPage;
  }

  get CurrentPage() {
    return this._currentPage;
  }

  async getFavouriteBooks() {
    
    this._progressLoader = true;
    this._searchDataFlag = false;
    this._errorMessageFlag = false;

    let authenticateResponse = this._authenticateService.getLoggedInUser();
    let authToken : string = authenticateResponse.authToken;
    let userEmailId : string = authenticateResponse.userEmailId;
    let userId : string = authenticateResponse.userId;

    try {
      this._searchBookDetailsList = await this._fetchBookService.getFavouriteBooks(authToken, userEmailId, userId);
      if(this._searchBookDetailsList.length == 0)  {
        this._searchDataFlag = false;
      } else {
        this._searchDataFlag = true;
      }
    } catch (searchBookError) {
      this._errorMessageFlag = true;
      if(searchBookError._errorCode == 0) {
        this._errorMessage = searchBookError._errorCode +
          " : " + searchBookError._errorMessage;
      } else {
        if(searchBookError._searchBookApiError.statusCode == 505 
          || searchBookError._searchBookApiError.statusCode == 506) {

            alert(searchBookError._searchBookApiError.message + " : You will be redirected to login page !");
            this._authenticateService.logoutUser();
            this._router.navigate(["mybooklogin"]);

        } else {
          this._errorMessage = searchBookError._searchBookApiError.statusCode +
          " : " + searchBookError._searchBookApiError.message;
        }
      }
    }

    this._progressLoader = false;
  }

  async deleteBookFromFavourite(searchBookDetails : SearchBookDetails) {
    
    let index : number = this._searchBookDetailsList.indexOf(searchBookDetails);
    let authenticateResponse = this._authenticateService.getLoggedInUser();
    let authtoken : string = authenticateResponse.authToken;
    let userEmailId : string = authenticateResponse.userEmailId;
    let userId : string = authenticateResponse.userId;

    this.openDialog(searchBookDetails, authtoken, userEmailId, userId, index);
  }

  openDialog(searchBookDetails : SearchBookDetails,
    authtoken : string,
    userEmailId : string,
    userId : string,
    index : number) : void {

    let dialougeData = new SearchBookDialouge();
    dialougeData._searchBookDetails = searchBookDetails;
    dialougeData._userEmailId = userEmailId;
    dialougeData._opearationName = "DELETE_BOOK_FROM_FAVOURITE";
    dialougeData._authToken = authtoken;
    dialougeData._userId = userId;

    const dialogRef = this._dialouge.open(DialougeMyBookComponent, {
      width : '450px',
      data : dialougeData
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result == "TRUE") {
        this._searchBookDetailsList.splice(index, 1);
        if(this._searchBookDetailsList.length == 0)  {
          this._searchDataFlag = false;
        }
      } else if(result == "TOKEN_EXPIRED") {
        this._router.navigate(["mybooklogin"]);
      }
    });
  }

}
