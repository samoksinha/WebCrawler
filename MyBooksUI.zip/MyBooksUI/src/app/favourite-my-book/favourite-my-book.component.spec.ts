import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FavouriteMyBookComponent } from './favourite-my-book.component';

describe('FavouriteMyBookComponent', () => {
  let component: FavouriteMyBookComponent;
  let fixture: ComponentFixture<FavouriteMyBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FavouriteMyBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FavouriteMyBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
