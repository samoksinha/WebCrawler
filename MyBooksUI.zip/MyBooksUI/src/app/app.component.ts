import { Component } from '@angular/core';

@Component({
  selector: 'app-myBook-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  private _title = 'My Books';

  get title() {
    return this._title;
  }
  
}
