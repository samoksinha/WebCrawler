import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Validators, FormControl } from '@angular/forms';
import { UserRegistration } from '../model/rgistration-request.model';
import { AuthenticateService } from '../service/authenticate-service.service';

@Component({
  selector: 'app-signup-my-book',
  templateUrl: './signup-my-book.component.html',
  styleUrls: ['./signup-my-book.component.css']
})
export class SignupMyBookComponent {

  private _firstname = new FormControl('', [Validators.required]);
  private _lastname = new FormControl('', [Validators.required]);
  private _email = new FormControl('', [Validators.required]);
  private _phone = new FormControl('', [Validators.required]);
  private _password = new FormControl('', [Validators.required]);
  private _confirmPassword = new FormControl('', [Validators.required]);
  
  private _passwordHideFlag : boolean;
  private _router : Router;
  private _authenticateService : AuthenticateService;

  private _errorMessage : string;
  private _errorMessageFlag : boolean;

  private _progressLoader : boolean;
  
  constructor(router : Router,
    authenticateService : AuthenticateService) {
    this._router = router;
    this._authenticateService = authenticateService;
    this._passwordHideFlag = true;
  }

  getFirstNameErrorMessage() : string {
    if(this._firstname.hasError('required')) {
      return 'You must enter a value for Firstname !';
    }
  }
  getLaststNameErrorMessage() : string {
    if(this._lastname.hasError('required')) {
      return 'You must enter a value for Lastname !';
    }
  }
  getEmailErrorMessage() : string {
    if(this._email.hasError('required')) {
      return 'You must enter a value for Email Id !';
    }
  }
  getPhoneErrorMessage() : string {
    if(this._phone.hasError('required')) {
      return 'You must enter a value for Mobile Number !';
    }
  }
  getPasswordErrorMessage() : string {
    if(this._password.hasError('required')) {
      return 'You must enter a value for Password !';
    }
  }
  getConfirmPasswordErrorMessage() : string {
    if(this._confirmPassword.hasError('required')) {
      return 'You must enter a value for Confirm Password !';
    }
  }

  get ErrorMessageFlag() {
    return this._errorMessageFlag;
  }

  getLoginErrorMessage() : string {
    return this._errorMessage; 
  }

  get ProgressLoader() {
    return this._progressLoader;
  }

  async myBookLoginSubmit() {

    if(this._firstname.value == null
      || this._firstname.value.length == 0) {
        alert("Please enter value for FirstName !");
        return true;
    }

    if(this._lastname.value == null
      || this._lastname.value.length == 0) {
        alert("Please enter value for LastName !");
        return true;
    }

    if(this._email.value == null
      || this._email.value.length == 0) {
        alert("Please enter value for Email Id !");
        return true;
    }

    if(this._phone.value == null
      || this._phone.value.length == 0) {
        alert("Please enter value for Phone Number !");
        return true;
    }

    if(this._password.value == null
      || this._password.value.length == 0) {
        alert("Please enter value for Password !");
        return true;
    }

    if(this._confirmPassword.value == null
      || this._confirmPassword.value.length == 0) {
        alert("Please enter value for Confirm Password !");
        return true;
    }
    
    if(this._password.value != this._confirmPassword.value) {
      alert("Password and Confirm Password should be same !");
      return true;
    }

    this._progressLoader = true;
    let userRegistration : UserRegistration = new UserRegistration();
    userRegistration.userFirstName = this._firstname.value;
    userRegistration.userLstName = this._lastname.value;
    userRegistration.userEmailId = this._email.value;
    userRegistration.userPhone = this._phone.value;
    userRegistration.userPassword = this._password.value;

    try {
      userRegistration = await this._authenticateService.userRegistration(userRegistration);
      alert("Registration successfull. You will be redirected to login page !");
      this._router.navigate(['mybooklogin']);

    } catch (searchBookError) {
      this._errorMessageFlag = true;
      this._progressLoader = false;

      if(searchBookError._errorCode == 0) {
        this._errorMessage = searchBookError._errorCode +
          " : " + searchBookError._errorMessage;
      } else {
        if(searchBookError._searchBookApiError.statusCode == 401) {
          this._errorMessage = searchBookError._searchBookApiError.statusCode +
          " : " + "User already Exist with the Email Id. Please use another Email ID !";
        } else {
          this._errorMessage = searchBookError._searchBookApiError.statusCode +
          " : " + searchBookError._searchBookApiError.message;
        }
      }
    }
  }

}
