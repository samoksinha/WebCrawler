import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignupMyBookComponent } from './signup-my-book.component';

describe('SignupMyBookComponent', () => {
  let component: SignupMyBookComponent;
  let fixture: ComponentFixture<SignupMyBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignupMyBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignupMyBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
