import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeMyBookComponent } from './home-my-book.component';

describe('HomeMyBookComponent', () => {
  let component: HomeMyBookComponent;
  let fixture: ComponentFixture<HomeMyBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeMyBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeMyBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
