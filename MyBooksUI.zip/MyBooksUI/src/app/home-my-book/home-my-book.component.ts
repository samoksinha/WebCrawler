import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DataCommunicationServiceService } from '../service/data-communication-service.service';
import { SearchBookDetails } from '../model/search-book-details.model';
import { SearchBook } from '../model/search-book.model';
import { FormControl, Validators } from '@angular/forms';
import { FetchBookService } from '../service/fetch-book-service.service';
import { SearchBookError } from '../model/search-book.-error.model';
import { AuthenticateService } from '../service/authenticate-service.service';
import { MatDialog } from '@angular/material/dialog';
import { DialougeMyBookComponent } from '../dialouge-my-book/dialouge-my-book.component';
import { SearchBookDialouge } from '../model/search-book-dialouge.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-my-book',
  templateUrl: './home-my-book.component.html',
  styleUrls: ['./home-my-book.component.css']
})
export class HomeMyBookComponent implements OnInit {

  private _bookSearch = new FormControl('', [Validators.required]);
  private _progressLoader : boolean;
  private _errorMessage : string;
  private _errorMessageFlag : boolean;
  private _searchDataFlag : boolean;
  private _itemsPerPage : number;
  private _currentPage : number;
  private _progressBarLoader : boolean;
  private _dialouge: MatDialog;

  private _searchBookDetailsList : SearchBookDetails[];
  private _dataCommunicationServiceService : DataCommunicationServiceService;
  private _fetchBookService : FetchBookService;
  private _authenticateService : AuthenticateService;
  private _router : Router;

  @ViewChild('bookSearch') _bookSearchElement : ElementRef;
  
  constructor(dataCommunicationServiceService : DataCommunicationServiceService,
              fetchBookService : FetchBookService,
              authenticateService : AuthenticateService,
              dialouge: MatDialog,
              router : Router) {
    this._dataCommunicationServiceService = dataCommunicationServiceService;
    this._fetchBookService = fetchBookService;
    this._authenticateService = authenticateService;
    this._progressLoader = false;
    this._errorMessage = "";
    this._errorMessageFlag = false;
    this._searchDataFlag = false;
    this._itemsPerPage = 3;
    this._currentPage =1;
    this._progressBarLoader = false;
    this._dialouge = dialouge;
    this._router = router;
  }

  ngOnInit() {
    //this._dataCommunicationServiceService._searchBookDetailsList
    //    .subscribe((searchBookDetailsList: SearchBookDetails[]) => {
    //    this._searchBookDetailsList = searchBookDetailsList;
    //    console.log(this._searchBookDetailsList);
    //});

    this._dataCommunicationServiceService._hideComponet.subscribe(hideComponentFlag  => {
      this._searchDataFlag = hideComponentFlag;
      this._bookSearchElement.nativeElement.focus();
      this._bookSearch.setValue(" ");
    });
  }

  get ProgressLoader() : boolean {
    return this._progressLoader;
  }

  get ProgressBarLoader() : boolean {
    return this._progressBarLoader;
  }

  getSearchErrorMessage() : string {
    if(this._bookSearch.hasError('required')) {
      this._errorMessage = "201 : You must enter a value for Book Title Search !";
      return this._errorMessage; 
    } else {
      return this._errorMessage;
    }
  }

  get ErrorMessageFlag() {
    return this._errorMessageFlag;
  }

  get SearchBookDetailsList() {
    return this._searchBookDetailsList;
  }

  get SearchDataFlag() {
    return this._searchDataFlag;
  }

  get ItemsPerPage() {
    return this._itemsPerPage;
  }

  get CurrentPage() {
    return this._currentPage;
  }

  async searchBooksByTitle() {

    let bookSearchValue : string = this._bookSearch.value;
    let searchBook : SearchBook = new SearchBook();
    try {
      this._progressLoader = true;
      this._errorMessageFlag = false;
      this._searchDataFlag = false;
      this._itemsPerPage = 3;
      this._currentPage =1;
      
      if(bookSearchValue != null
          && bookSearchValue.length > 0) {
            searchBook = await this._fetchBookService.searchBooksByTitle(bookSearchValue.trim());
            if(searchBook.SearchBookDetailsList.length == 0) {
                throw new SearchBookError("202", 
                "No related books or result found for the search value !", 
                "CUSTOM_VALIDATION_ERROR", null);
              }
      } else {
        throw new SearchBookError("201", 
        "You must enter a value for Book Title Search !", 
        "CUSTOM_VALIDATION_ERROR", null);
      }
    } catch (searchBookError) {
      this._errorMessageFlag = true;
      if(searchBookError._errorCode == 0) {
        this._errorMessage = searchBookError._errorCode +
          " : " + searchBookError._errorMessage;
      } else {
        this._errorMessage = searchBookError._searchBookApiError.statusCode +
          " : " + searchBookError._searchBookApiError.message;
      }
    }

    this._progressLoader = false;
    if(!this._errorMessageFlag) {
      this._searchDataFlag = true;
      this._searchBookDetailsList = searchBook.SearchBookDetailsList;
      //console.log(JSON.stringify(this._searchBookDetailsList[0]));
      //console.log(JSON.stringify(this._searchBookDetailsList[1]));
    }
  }

  async addBookToFavourite(searchBookDetails : SearchBookDetails) {
    
    let index : number = this._searchBookDetailsList.indexOf(searchBookDetails);
    let authenticateResponse = this._authenticateService.getLoggedInUser();
    let authtoken : string = authenticateResponse.authToken;
    let userEmailId : string = authenticateResponse.userEmailId;
    let userId : string = authenticateResponse.userId;

    this.openDialog(searchBookDetails, authtoken, userEmailId, userId, index);
  }

  openDialog(searchBookDetails : SearchBookDetails,
    authtoken : string,
    userEmailId : string,
    userId : string,
    index : number) : void {

    let dialougeData = new SearchBookDialouge();
    dialougeData._searchBookDetails = searchBookDetails;
    dialougeData._userEmailId = userEmailId;
    dialougeData._opearationName = "ADD_BOOK_TO_FAVOURITE";
    dialougeData._authToken = authtoken;
    dialougeData._userId = userId;

    const dialogRef = this._dialouge.open(DialougeMyBookComponent, {
      width : '450px',
      data : dialougeData
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result) {
        if(result == "TRUE") {
          this._searchBookDetailsList.splice(index, 1);
        } else if(result == "TOKEN_EXPIRED") {
          this._router.navigate(["mybooklogin"]);
        }
      }
    });
  }

}
