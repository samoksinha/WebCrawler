import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticateRequest } from '../model/authenticate-request.model';
import { AuthenticateService } from '../service/authenticate-service.service';

@Component({
  selector: 'app-forgot-password-my-book',
  templateUrl: './forgot-password-my-book.component.html',
  styleUrls: ['./forgot-password-my-book.component.css']
})
export class ForgotPasswordMyBookComponent {

  private _username = new FormControl('', [Validators.required]);
  private _password = new FormControl('', [Validators.required]);
  private _confirmPassword = new FormControl('', [Validators.required]);

  private _passwordHideFlag : boolean;
  private _router : Router;
  private _authenticateService : AuthenticateService;

  private _errorMessage : string;
  private _errorMessageFlag : boolean;

  private _progressLoader : boolean;
  
  constructor(router : Router, 
    authenticateService : AuthenticateService) {

    this._router = router;
    this._authenticateService = authenticateService;
    this._passwordHideFlag = true;

    this._errorMessage = "";
    this._errorMessageFlag = false;
    this._progressLoader = false;
  }

  set Username(username) {
    this._username = username;
  }
  set Password(password) {
    this._password = password;
  }

  get PasswordHideFlag() {
    return this._passwordHideFlag;
  }

  get ErrorMessageFlag() {
    return this._errorMessageFlag;
  }

  getForgotPasswordErrorMessage() : string {
    return this._errorMessage; 
  }

  getUsernameErrorMessage() : string {
    if(this._username.hasError('required')) {
      return 'You must enter a value for Username !';
    }
  }
  getPasswordErrorMessage() : string {
    if(this._password.hasError('required')) {
      return 'You must enter a value for Change Password !';
    }
  }

  getConfirmPasswordErrorMessage() : string {
    if(this._confirmPassword.hasError('required')) {
      return 'You must enter a value for Confirm Password !';
    }
  }

  get ProgressLoader() {
    return this._progressLoader;
  }

  async myBookForgotPasswordSubmit() {
    
    let authenticateRequest = new AuthenticateRequest();
    try {
      if(this._password.value != this._confirmPassword.value) {
        alert("Password and Confirm Password should be same !");
        return true;
      }

      this._progressLoader = true;

      authenticateRequest.userEmailId = this._username.value;
      authenticateRequest.userPassword = this._password.value;
      await this._authenticateService.forgotPassword(authenticateRequest);

      alert("Password successfully changed. You will be redirected to login page !");
      this._router.navigate(["mybooklogin"]);
      
    } catch (searchBookError) {
      this._errorMessageFlag = true;
      this._progressLoader = false;

      if(searchBookError._errorCode == 0) {
        this._errorMessage = searchBookError._errorCode +
          " : " + searchBookError._errorMessage;
      } else {
        this._errorMessage = searchBookError._searchBookApiError.statusCode +
          " : " + searchBookError._searchBookApiError.message;
      }
    }
  }

}
