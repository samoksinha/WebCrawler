import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotPasswordMyBookComponent } from './forgot-password-my-book.component';

describe('ForgotPasswordMyBookComponent', () => {
  let component: ForgotPasswordMyBookComponent;
  let fixture: ComponentFixture<ForgotPasswordMyBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForgotPasswordMyBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgotPasswordMyBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
