import { Component } from '@angular/core';
import { AuthenticateService } from '../service/authenticate-service.service';
import { Router } from '@angular/router';
import { Validators, FormControl } from '@angular/forms';
import { FetchBookService } from '../service/fetch-book-service.service';
import { SearchBook } from '../model/search-book.model';
import { DataCommunicationServiceService } from '../service/data-communication-service.service';

@Component({
  selector: 'app-header-my-book',
  templateUrl: './header-my-book.component.html',
  styleUrls: ['./header-my-book.component.css']
})
export class HeaderMyBookComponent {

  private _bookSearch = new FormControl('', [Validators.required]);

  private _router : Router;
  private _authenticateService : AuthenticateService;
  private _fetchBookService : FetchBookService;
  private _dataCommunicationServiceService : DataCommunicationServiceService;

  constructor(router : Router, authenticateService : AuthenticateService, 
              fetchBookService : FetchBookService,
              dataCommunicationServiceService : DataCommunicationServiceService) {
    this._router = router;
    this._authenticateService = authenticateService;
    this._fetchBookService = fetchBookService;
    this._dataCommunicationServiceService = dataCommunicationServiceService;
  }

  isLoggedIn() : boolean {
    return this._authenticateService.isLoggedIn();
  }

  getLoggedinUsername() : string {
    let authenticateResponse = this._authenticateService.getLoggedInUser();
    //console.log("HeaderMyBookComponent : getLoggedinUsername : Method : authenticate : " +authenticate._username);
    return authenticateResponse.userFirstName;
  }

  logoutUser() {
    let logOutFlag = this._authenticateService.logoutUser();
    //console.log("HeaderMyBookComponent : logoutUser : Method : logOutFlag : " +logOutFlag);
    this._router.navigate(['mybooklogin']);
  }

  refrshHome() {
    this._dataCommunicationServiceService.hideComponent(false);
    this._router.navigate(["/mybookhome"]);
  }

  async searchBooksByTitle() {
    let bookSearchValue = this._bookSearch.value;
    let searchBook : SearchBook = new SearchBook();
    try {
      searchBook = await this._fetchBookService.searchBooksByTitle(bookSearchValue);
    } catch (searchBookError) {
      console.log("Error Code : " +searchBookError.getErrorCode()+ 
                  " : Error Message : " +searchBookError.getErrorMessage()+
                  " : Error Type : " +searchBookError.getName);
      alert("Error Code : " +searchBookError.getErrorCode()+ 
            " : Error Message : " +searchBookError.getErrorMessage()+
            " : Error Type : " +searchBookError.getName);
    }
    
    //console.log(searchBook.SearchBookDetailsList);
    this._dataCommunicationServiceService.shareSearchBookDetailsData(searchBook.SearchBookDetailsList);
    this._router.navigate(["/mybookhome"]);
  }

}
