import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderMyBookComponent } from './header-my-book.component';

describe('HeaderMyBookComponent', () => {
  let component: HeaderMyBookComponent;
  let fixture: ComponentFixture<HeaderMyBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderMyBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderMyBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
