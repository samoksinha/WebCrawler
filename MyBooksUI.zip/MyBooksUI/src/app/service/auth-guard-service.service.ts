import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticateService } from './authenticate-service.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService implements CanActivate {

  private _router : Router;
  private _authenticateService : AuthenticateService;

  constructor(authenticateService : AuthenticateService, router : Router) { 
    this._authenticateService = authenticateService;
    this._router = router;
  }

  canActivate(next : ActivatedRouteSnapshot, state : RouterStateSnapshot) 
    : Observable<boolean> | Promise<boolean> | boolean {
    //console.log("AuthguardService : canActivate : Method : isLoggedIn : " +this._authenticateService.isLoggedIn());
    if (this._authenticateService.isLoggedIn()) {
        return true;
    } else {
      this._router.navigate(['/mybooklogin']);
      return false;
    }
  }

}
