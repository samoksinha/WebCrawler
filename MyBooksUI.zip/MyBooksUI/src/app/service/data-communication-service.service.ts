import { Injectable } from '@angular/core';
import { SearchBookDetails } from '../model/search-book-details.model';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataCommunicationServiceService {

  private _searchBookDetailsSource$ = new BehaviorSubject<SearchBookDetails[]>(null);
  _searchBookDetailsList = this._searchBookDetailsSource$.asObservable();

  private _hideComponetSource$ = new BehaviorSubject<boolean>(false);
  _hideComponet = this._hideComponetSource$.asObservable();
  
  constructor() {
  }

  shareSearchBookDetailsData(searchBookDetailsList : SearchBookDetails[]) : void {
    this._searchBookDetailsSource$.next(searchBookDetailsList);
  }

  hideComponent(hideComponentFlag : boolean) : void {
    this._hideComponetSource$.next(hideComponentFlag);
  }
  
}
