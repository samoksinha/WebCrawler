import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SearchBook } from '../model/search-book.model';
import { JsonConvert } from 'json2typescript';
import { SearchBookError } from '../model/search-book.-error.model';
import { SearchBookDetails } from '../model/search-book-details.model';
import { SearchBookApiError } from '../model/search-book.-api-error.model.';

@Injectable({
  providedIn: 'root'
})
export class FetchBookService {

  private _httpClient : HttpClient;
  private _jsonConvert : JsonConvert;
  
  constructor(httpclient : HttpClient) { 
    this._httpClient = httpclient;
    this._jsonConvert = new JsonConvert();
  }

  async searchBooksByTitle(bookSearchValue : string) : Promise<SearchBook> {
    let searchbook : SearchBook;

    bookSearchValue = bookSearchValue.split(" ").join("+");
    let url : string = "http://openlibrary.org/search.json?title=" +bookSearchValue;
    //alert(url);

    try {
      const responseData = await this._httpClient.get(url).toPromise();
      searchbook = this._jsonConvert.deserializeObject(responseData, SearchBook);
    } catch (searchBookError) {
      throw searchBookError;
    }
    
    return searchbook;
  }

  async addBookToFavourite(authToken : string,
    userEmailId : string,
    userId : string,
    searchBookDetails : SearchBookDetails) : Promise<SearchBookDetails[]> {

    let addFavouriteBook : string;
    let addFavouriteBookList : SearchBookDetails[];

    addFavouriteBook = JSON.stringify(searchBookDetails);
    //alert("addFavouriteBook String : " +addFavouriteBook);
    let url : string = "http://localhost:8086/rest/api/v1/favouriteService/insertFavouriteBook";
    //alert(url);

    let httpHeaders = new HttpHeaders()
      .set("Content-Type", "application/json")
      .set("authorization", authToken)
      .set("debugflag", "false")
      .set("emailId", userEmailId)
      .set("userId", userId);
    let httpHeadersOptions = {
      headers: httpHeaders
    }; 

    try {
      const responseData = await this._httpClient
        .post(url, addFavouriteBook, httpHeadersOptions)
        .toPromise();
      addFavouriteBookList = Array.of(JSON.parse(JSON.stringify(responseData)));
    } catch (searchBookError) {
      throw searchBookError;
    }
    
    return addFavouriteBookList;
  }

  async deleteBookFromFavourite(authToken : string,
    userEmailId : string,
    userId : string,
    searchBookDetails : SearchBookDetails) : Promise<SearchBookDetails[]> {

    let addFavouriteBook : string;
    let addFavouriteBookList : SearchBookDetails[];

    addFavouriteBook = JSON.stringify(searchBookDetails);
    //alert("addFavouriteBook String : " +addFavouriteBook);
    let url : string = "http://localhost:8086/rest/api/v1/favouriteService/deleteFavouriteBook";
    //alert(url);

    let httpHeaders = new HttpHeaders()
      .set("Content-Type", "application/json")
      .set("authorization", authToken)
      .set("debugflag", "false")
      .set("emailId", userEmailId)
      .set("userId", userId);
    let httpHeadersOptions = {
      headers: httpHeaders
    }; 

    try {
      const responseData = await this._httpClient
        .post(url, addFavouriteBook, httpHeadersOptions)
        .toPromise();
      addFavouriteBookList = Array.of(JSON.parse(JSON.stringify(responseData)));
    } catch (searchBookError) {
      throw searchBookError;
    }
    
    return addFavouriteBookList;
  }

  async getFavouriteBooks(authToken : string,
    userEmailId : string,
    userId : string) : Promise<SearchBookDetails[]> {

    let getFavouriteBookList : SearchBookDetails[];
    
    let url : string = "http://localhost:8086/rest/api/v1/favouriteService/getFavouriteBooks";
    let httpHeaders = new HttpHeaders()
      .set("Content-Type", "application/json")
      .set("authorization", authToken)
      .set("debugflag", "false")
      .set("emailId", userEmailId)
      .set("userId", userId);
    let httpHeadersOptions = {
      headers: httpHeaders
    }; 

    try {
      const responseData = await this._httpClient
        .get(url, httpHeadersOptions)
        .toPromise();
      //getFavouriteBookList = Array.of(JSON.parse(JSON.stringify(responseData)));
      getFavouriteBookList = <SearchBookDetails[]> responseData;
    } catch (searchBookError) {
      throw searchBookError;
    }
    
    return getFavouriteBookList;
  }

}
