import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticateRequest } from '../model/authenticate-request.model';
import { AuthenticateResponse } from '../model/authenticate-reponse.model';
import { UserRegistration } from '../model/rgistration-request.model';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

  //private _authenticateDataSource = new Subject<Authenticate>();
  //authenticateData$ = this._authenticateDataSource.asObservable();

  //constructor() { 
  //}

  //sendAuthenticateData(authenticate : Authenticate) {
    //this._authenticateDataSource.next(authenticate);
  //}

  private _httpClient : HttpClient;
  
  constructor(httpclient : HttpClient) {
    this._httpClient = httpclient;
  }
  
  async loginAuthenticate(authenticateRequest : AuthenticateRequest) {

    let authenticateRequestJson : string;
    let authenticateResponse : AuthenticateResponse;
    let url : string;
    let httpHeaders : HttpHeaders;
    try { 
      authenticateRequestJson = JSON.stringify(authenticateRequest);
      //alert("authenticateJson : " +authenticateRequestJson);
      
      url = "http://localhost:8088/rest/api/v1/userDetailsService/login";
      httpHeaders = new HttpHeaders()
        .set("Content-Type", "application/json")
        .set("debugFlag", "false");
      let httpHeadersOptions = {
        headers: httpHeaders
      }; 
        
      const responseData = await this._httpClient
        .post(url, authenticateRequestJson, httpHeadersOptions)
        .toPromise();
      authenticateResponse = <AuthenticateResponse> responseData;
      //alert("responseData" + JSON.stringify(authenticateResponse));

      sessionStorage.setItem("CURRENT_USER", JSON.stringify(authenticateResponse));
    } catch (searchBookError) {
      throw searchBookError;
    }
    
    return authenticateResponse;
  }

  async forgotPassword(authenticateRequest : AuthenticateRequest) {

    let authenticateRequestJson : string;
    let authenticateResponse : AuthenticateResponse;
    let url : string;
    let httpHeaders : HttpHeaders;
    try { 
      authenticateRequestJson = JSON.stringify(authenticateRequest);
      //alert("authenticateJson : " +authenticateRequestJson);
      
      url = "http://localhost:8088/rest/api/v1/userDetailsService/forgotPassword";
      httpHeaders = new HttpHeaders()
        .set("Content-Type", "application/json")
        .set("debugFlag", "false");
      let httpHeadersOptions = {
        headers: httpHeaders
      }; 
        
      const responseData = await this._httpClient
        .post(url, authenticateRequestJson, httpHeadersOptions)
        .toPromise();
      authenticateResponse = <AuthenticateResponse> responseData;
      //alert("responseData" + JSON.stringify(authenticateResponse));
      
    } catch (searchBookError) {
      throw searchBookError;
    }
    
    return authenticateResponse;
  }

  async userRegistration(userRegistration : UserRegistration) {

    let userRegistrationJson : string;
    let url : string;
    let httpHeaders : HttpHeaders;
    try { 
      userRegistrationJson = JSON.stringify(userRegistration);
      //alert("authenticateJson : " +userRegistrationJson);
      
      url = "http://localhost:8088/rest/api/v1/userDetailsService/registration";
      httpHeaders = new HttpHeaders()
        .set("Content-Type", "application/json")
        .set("debugFlag", "false");
      let httpHeadersOptions = {
        headers: httpHeaders
      }; 
        
      const responseData = await this._httpClient
        .post(url, userRegistrationJson, httpHeadersOptions)
        .toPromise();
        userRegistration = <UserRegistration> responseData;
      //alert("responseData" + JSON.stringify(userRegistration));

    } catch (searchBookError) {
      throw searchBookError;
    }
    
    return userRegistration;
  }

  isLoggedIn() : boolean {
    let authenticateResponse : AuthenticateResponse;
    let currentUser = sessionStorage.getItem("CURRENT_USER");
    if(currentUser != null) {
      authenticateResponse = JSON.parse(currentUser);
      //console.log("AuthenticateService : isLoggedIn : Method : authenticate : " +authenticate);
    }

    if(authenticateResponse != null 
      && (authenticateResponse.authToken != null 
        && authenticateResponse.authToken.length > 0)) {
        return true;
    } else {
      return false;
    }
  }

  getLoggedInUser() : AuthenticateResponse {
    let currentUser = sessionStorage.getItem("CURRENT_USER");
    if(currentUser != null) {
      let authenticateResponse : AuthenticateResponse = JSON.parse(currentUser);
      return authenticateResponse;
    } else {
      return null;
    }
  }

  logoutUser() : boolean {
    sessionStorage.removeItem("CURRENT_USER");
    let currentUser = sessionStorage.getItem("CURRENT_USER");
    //console.log("AuthenticateService : logoutUser : Method : currentUser : " +currentUser);
    if (currentUser == null 
        || currentUser.length == 0) {
      return true;
    } else {
      return false;
    }
  }

}
