import { TestBed } from '@angular/core/testing';

import { FetchBookServiceService } from './fetch-book-service.service';

describe('FetchBookServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FetchBookServiceService = TestBed.get(FetchBookServiceService);
    expect(service).toBeTruthy();
  });
});
