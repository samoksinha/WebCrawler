import { TestBed } from '@angular/core/testing';

import { DataCommunicationServiceService } from './data-communication-service.service';

describe('DataCommunicationServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DataCommunicationServiceService = TestBed.get(DataCommunicationServiceService);
    expect(service).toBeTruthy();
  });
});
