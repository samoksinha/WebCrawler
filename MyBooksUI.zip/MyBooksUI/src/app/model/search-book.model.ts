
import {JsonObject, JsonProperty} from "json2typescript";
import { SearchBookDetails } from "./search-book-details.model";

@JsonObject
export class SearchBook {

    @JsonProperty("start", Number)
    private _start : number = undefined;

    @JsonProperty("num_found", Number)
    private _numFound : number = undefined;

    @JsonProperty("docs")
    private _docs : any[] = undefined;

    private _searchBookDetailsList : SearchBookDetails[];

    constructor() {
        this._searchBookDetailsList = [];
    }

    get Start() { 
        return this._start; 
    }
    set Start(start: number) { 
        this._start = start; 
    }

    get NumFound() { 
        return this._numFound; 
    }
    set NumFound(numFound: number) { 
        this._numFound = numFound; 
    }

    get Docs() { 
        return this._docs; 
    }
    set Docs(docs: SearchBookDetails[]) { 
        this._docs = docs; 
    }

    get SearchBookDetailsList() { 
        for(let doc of this._docs) {

            let searchBookDetails = new SearchBookDetails();
            for(let [key, value] of Object.entries(doc)) {
                if(key == "cover_edition_key") {
                    let openLibraryIdArray : string[] = new Array (1);
                    openLibraryIdArray[0] = new String(value).valueOf();
                    searchBookDetails._openLibraryId = openLibraryIdArray;
                } else if(key == "edition_key") {
                    searchBookDetails._openLibraryId = Object.values(value);
                }

                if(key == "author_key") {
                    searchBookDetails._authorKey = Object.values(value);
                }
                if(key == "author_name") {
                    searchBookDetails._authorName = Object.values(value);
                }
                if(key == "first_publish_year") {
                    searchBookDetails._firstPublishedYear = new Number(value).valueOf();
                }
                if(key == "has_fulltext") {
                    searchBookDetails._hasFullText = new Boolean(value).valueOf();
                }
                if(key == "isbn") {
                    searchBookDetails._isbn = Object.values(value);
                }
                if(key == "language") {
                    searchBookDetails._language = Object.values(value);
                }
                if(key == "publish_year") {
                    searchBookDetails._publishYear = Object.values(value);
                }
                if(key == "publisher") {
                    searchBookDetails._publisher = Object.values(value);
                }
                if(key == "title") {
                    searchBookDetails._title = new String(value).valueOf();
                }
                if(key == "title_suggest") {
                    searchBookDetails._titleSuggest = new String(value).valueOf();
                }
                if(key == "type") {
                    searchBookDetails._type = new String(value).valueOf();
                }

                if(searchBookDetails._openLibraryId != null 
                    && searchBookDetails._openLibraryId.length > 0) {
                    searchBookDetails._imageUrl = "http://covers.openlibrary.org/b/olid/" + searchBookDetails._openLibraryId[0] + "-L.jpg?default=false";
                }
            }

            this._searchBookDetailsList.push(searchBookDetails);
        }

        return this._searchBookDetailsList;
    }

}
