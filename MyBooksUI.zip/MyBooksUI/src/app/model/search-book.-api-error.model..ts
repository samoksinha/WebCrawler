
export class SearchBookApiError {

    timestamp : string;
    statusCode : number;
    path : string
    message : string;
    errorDetails : string[];

    constructor() {
    }

}
