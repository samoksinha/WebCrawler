
export class AuthenticateRequest {

    userEmailId : string;
    userPassword : string;

    constructor() {
        this.userEmailId = "";
        this.userPassword = "";
    }

    get UserEmailId() {
        return this.userEmailId;
    }
    set UserEmailId(userEmailId) {
        this.userEmailId = userEmailId;
    }

    get UserPassword() {
        return this.userPassword;
    }
    set UserPassword(userPassword) {
        this.userPassword = userPassword;
    }

}
