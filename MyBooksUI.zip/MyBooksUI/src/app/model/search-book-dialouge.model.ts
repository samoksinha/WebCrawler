import { SearchBookDetails } from "./search-book-details.model";

export class SearchBookDialouge {

    _searchBookDetails : SearchBookDetails;
    _userEmailId : string;
    _statusFlag : string;
    _opearationName : string;
    _authToken : string;
    _userId : string;

    constructor() {
    }

}
