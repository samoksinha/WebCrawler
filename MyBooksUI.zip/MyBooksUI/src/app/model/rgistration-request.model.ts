
export class UserRegistration {

    userId : string;
    userFirstName : string;
    userLstName : string;
	userEmailId : string;
	userPhone : string;
	userPassword : string;

    constructor() {
        this.userId = "";
        this.userFirstName = "";
        this.userLstName = "";
        this.userEmailId = "";
        this.userPhone = "";
        this.userPassword = "";
    }

}
