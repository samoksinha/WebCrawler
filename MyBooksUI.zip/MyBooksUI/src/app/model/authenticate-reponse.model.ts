
export class AuthenticateResponse {

    userEmailId : string;
    userPassword : string;
    authToken : string;
    tokenExpiry : number;
    userFirstName : string;
    userId : string;

    constructor() {
        this.userEmailId = "";
        this.userPassword = "";
        this.authToken = "";
        this.tokenExpiry = 0;
        this.userFirstName = "";
        this.userId = "";
    }

}
