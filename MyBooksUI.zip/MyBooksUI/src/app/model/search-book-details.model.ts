
export class SearchBookDetails {

    _openLibraryId : string[];
    _authorKey : string[];
    _authorName : string[];
    _firstPublishedYear : number;
    _hasFullText : boolean;
    _isbn : string[];
    _language : string[];
    _publishYear : number[];
    _publisher : string[];
    _title : string;
    _titleSuggest : string;
    _type : string;
    _imageUrl : string;
	
    constructor() {
    }

}
