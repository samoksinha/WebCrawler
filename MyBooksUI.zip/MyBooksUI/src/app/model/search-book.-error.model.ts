import { SearchBookApiError } from "./search-book.-api-error.model.";

export class SearchBookError implements Error {

    _errorCode : string;
    _errorMessage : string;
    
    _searchBookApiError : SearchBookApiError;

    name : string;
    message : string;

    constructor(errorCode : string, errorMessage : string, 
        typeOfError : string, 
        searchBookApiError : SearchBookApiError) {
        this._errorCode = errorCode;
        this._errorMessage = errorMessage;
        this.message = errorMessage;
        this.name = typeOfError;
        this._searchBookApiError = searchBookApiError;
    }

}
