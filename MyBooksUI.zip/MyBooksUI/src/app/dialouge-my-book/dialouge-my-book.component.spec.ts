import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialougeMyBookComponent } from './dialouge-my-book.component';

describe('DialougeMyBookComponent', () => {
  let component: DialougeMyBookComponent;
  let fixture: ComponentFixture<DialougeMyBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialougeMyBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialougeMyBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
