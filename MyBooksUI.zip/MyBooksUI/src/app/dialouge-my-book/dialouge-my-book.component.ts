import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SearchBookDialouge } from '../model/search-book-dialouge.model';
import { FetchBookService } from '../service/fetch-book-service.service';
import { SearchBookDetails } from '../model/search-book-details.model';
import { AuthenticateService } from '../service/authenticate-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dialouge-my-book',
  templateUrl: './dialouge-my-book.component.html',
  styleUrls: ['./dialouge-my-book.component.css']
})
export class DialougeMyBookComponent implements OnInit {
 
  private _fetchBookService : FetchBookService;
  private _authenticateService : AuthenticateService;
  
  _progressBarLoader : boolean;
  _status : string;
  _errorCode : number;
  _errorMessage : string;
  _successMessage : string;

  constructor(public dialougeRef : MatDialogRef<DialougeMyBookComponent>,
    @Inject(MAT_DIALOG_DATA) public data: SearchBookDialouge,
    fetchBookService : FetchBookService,
    authenticateService : AuthenticateService) {
      this._fetchBookService = fetchBookService;
      this._authenticateService = authenticateService;
  }

  ngOnInit() {
    this. dialougeRef.disableClose = true;
    this._progressBarLoader = true;

    if(this.data._opearationName == "ADD_BOOK_TO_FAVOURITE") {
      this.addBookToFavourite();
    } else if(this.data._opearationName == "DELETE_BOOK_FROM_FAVOURITE") {
      this.deleteBookFromFavourite();
    }
  }

  async addBookToFavourite() {

    let addFavouriteBookList : SearchBookDetails[];
    try {
      addFavouriteBookList = await this._fetchBookService
        .addBookToFavourite(this.data._authToken,
          this.data._userEmailId,
          this.data._userId,
          this.data._searchBookDetails);
      if(addFavouriteBookList.length > 0) {
        this._progressBarLoader = false;
        this.data._statusFlag = "TRUE";
        this._status = "SUCCESS";
        let successMessage = "Book has been successfully added to favourite. Book Name : " 
          +this.data._searchBookDetails._title;
        this._successMessage = successMessage;
      }
    } catch (searchBookError) {
      console.log("Exception Occured in Dialog Box : " +searchBookError._searchBookApiError.message);
      this._progressBarLoader = false;
      this._status = "ERROR";
      if(searchBookError._errorCode == 0) {
        this.data._statusFlag = "FALSE";
        this._errorCode = searchBookError._errorCode;
        this._errorMessage = searchBookError._errorMessage;

      } else {
        if(searchBookError._searchBookApiError.statusCode == 505 
          || searchBookError._searchBookApiError.statusCode == 506) {
            this.data._statusFlag = "TOKEN_EXPIRED";
            this._authenticateService.logoutUser();
            
            this._errorCode = searchBookError._searchBookApiError.statusCode;
            this._errorMessage = searchBookError._searchBookApiError.message +
              ". You will be redirected to login page !";
            
        } else {
          this.data._statusFlag = "FALSE";
          this._errorCode = searchBookError._searchBookApiError.statusCode;
          this._errorMessage = searchBookError._searchBookApiError.message;
        }
      }
    }
  }

  async deleteBookFromFavourite() {

    let deleteFavouriteBookList : SearchBookDetails[];
    try {
      deleteFavouriteBookList = await this._fetchBookService
        .deleteBookFromFavourite(this.data._authToken,
          this.data._userEmailId,
          this.data._userId,
          this.data._searchBookDetails);
      if(deleteFavouriteBookList.length >= 0) {
        this._progressBarLoader = false;
        this.data._statusFlag = "TRUE";
        this._status = "SUCCESS";
        let successMessage = "Book has been successfully deleted from favourite. Book Name : " 
          +this.data._searchBookDetails._title;
        this._successMessage = successMessage;
      }
    } catch (searchBookError) {
      console.log("Exception Occured in Dialog Box : " +searchBookError._searchBookApiError.message);
      this._progressBarLoader = false;
      this._status = "ERROR";
      if(searchBookError._errorCode == 0) {
        this.data._statusFlag = "FALSE";
        this._errorCode = searchBookError._errorCode;
        this._errorMessage = searchBookError._errorMessage;

      } else {
        if(searchBookError._searchBookApiError.statusCode == 505 
          || searchBookError._searchBookApiError.statusCode == 506) {
            this.data._statusFlag = "TOKEN_EXPIRED";
            this._authenticateService.logoutUser();

            this._errorCode = searchBookError._searchBookApiError.statusCode;
            this._errorMessage = searchBookError._searchBookApiError.message +
              ". You will be redirected to login page !";
            
        } else {
          this.data._statusFlag = "FALSE";
          this._errorCode = searchBookError._searchBookApiError.statusCode;
          this._errorMessage = searchBookError._searchBookApiError.message;
        }
      }
    }
  }
    
}
