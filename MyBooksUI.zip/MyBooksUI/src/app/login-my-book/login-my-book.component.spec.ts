import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginMyBookComponent } from './login-my-book.component';

describe('LoginMyBookComponent', () => {
  let component: LoginMyBookComponent;
  let fixture: ComponentFixture<LoginMyBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginMyBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginMyBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
