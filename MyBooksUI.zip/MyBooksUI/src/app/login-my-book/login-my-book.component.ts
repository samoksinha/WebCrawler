import { Component, Output, EventEmitter } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

import { Router } from '@angular/router';
import { AuthenticateService } from '../service/authenticate-service.service';
import { AuthenticateRequest } from '../model/authenticate-request.model';
import { AuthenticateResponse } from '../model/authenticate-reponse.model';

@Component({
  selector: 'app-login-my-book',
  templateUrl: './login-my-book.component.html',
  styleUrls: ['./login-my-book.component.css']
})

export class LoginMyBookComponent {

  private _username = new FormControl('', [Validators.required]);
  private _password = new FormControl('', [Validators.required]);

  private _passwordHideFlag : boolean;
  private _router : Router;
  private _authenticateService : AuthenticateService;

  private _errorMessage : string;
  private _errorMessageFlag : boolean;

  private _progressLoader : boolean;

  constructor(router : Router,
    authenticateService : AuthenticateService) {
      
    this._router = router;
    this._authenticateService = authenticateService;
    this._passwordHideFlag = true;

    this._errorMessage = "";
    this._errorMessageFlag = false;
    this._progressLoader = false;
  }

  set Username(username) {
    this._username = username;
  }
  set Password(password) {
    this._password = password;
  }

  get PasswordHideFlag() {
    return this._passwordHideFlag;
  }

  get ErrorMessageFlag() {
    return this._errorMessageFlag;
  }

  getLoginErrorMessage() : string {
    return this._errorMessage; 
  }

  getUsernameErrorMessage() : string {
    if(this._username.hasError('required')) {
      return 'You must enter a value for Username !';
    }
  }
  getPasswordErrorMessage() : string {
    if(this._password.hasError('required')) {
      return 'You must enter a value for Password !';
    }
  }

  get ProgressLoader() {
    return this._progressLoader;
  }

  async myBookLoginSubmit() {
    //const myBookUser: any = { username: this._username.value, password: this._password.value };
    console.log('Username : ' + this._username.value + ' : Password : ' +this._password.value);

    let authenticateRequest = new AuthenticateRequest();
    try {
      this._progressLoader = true;

      authenticateRequest.userEmailId = this._username.value;
      authenticateRequest.userPassword = this._password.value;
      await this._authenticateService.loginAuthenticate(authenticateRequest);

      this._router.navigate(["/mybookhome"]);
      
    } catch (searchBookError) {
      this._errorMessageFlag = true;
      this._progressLoader = false;

      if(searchBookError._errorCode == 0) {
        this._errorMessage = searchBookError._errorCode +
          " : " + searchBookError._errorMessage;
      } else {
        this._errorMessage = searchBookError._searchBookApiError.statusCode +
          " : " + searchBookError._searchBookApiError.message;
      }
    }
  }

}
