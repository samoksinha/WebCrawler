CREATE TABLE IF NOT EXISTS `my_book_store`.`favourite_books` (
  `favourite_book_id` INT NOT NULL AUTO_INCREMENT,
  `user_id` VARCHAR(45) NOT NULL,
  `email_id` VARCHAR(45) NOT NULL,
  `favourite_books_current_value` TEXT  NULL,
  `favourite_books_old_value` TEXT NULL,
  `favourite_books_updated_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `favourite_books_updated_by` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`favourite_book_id`));
  
  CREATE TABLE IF NOT EXISTS `my_book_store`.`user_details` (
  `user_details_id` INT NOT NULL AUTO_INCREMENT,
  `user_id` VARCHAR(45) NOT NULL,
  `user_firstName` VARCHAR(45) NOT NULL,
  `user_lastName` VARCHAR(45) NOT NULL,
  `user_emailId` VARCHAR(45) NOT NULL,
  `user_phone` VARCHAR(45) NOT NULL,
  `user_password` TEXT NOT NULL,
  `user_auth_token` TEXT,
  `user_details_updated_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `user_details_updated_by` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`user_details_id`));

ALTER TABLE `my_book_store`.`user_details` 
ADD UNIQUE INDEX `user_emailId_UNIQUE` (`user_emailId` ASC) VISIBLE;